export interface StockData {
  symbol: string;
  lastPrice: number;
  avgPrice: number;
  qty: number;
  dayChange: number;
  priceChange?: number;
  pnl: number;
  investmentDate?: Date;
  totalInvestment?: number;
}

export interface TechnicalAnalysis {
  rsi: number;
  macd: {
    value: number;
    signal: number;
    histogram: number;
  };
  rsiSignal: 'BUY' | 'SELL' | 'NEUTRAL';
  macdSignal: 'BUY' | 'SELL' | 'NEUTRAL';
  recommendation: 'STRONG BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG SELL';
}

export interface AnalysisData extends StockData, TechnicalAnalysis {}

export interface PriceData {
  price: number;
  change: number;
  changePercent: number;
}

export interface CSVRow {
  [key: string]: string | number | undefined;
  symbol?: string;
  tradingsymbol?: string;
  stock?: string;
  ticker?: string;
  lastprice?: number;
  ltp?: number;
  price?: number;
  currentprice?: number;
  avgprice?: number;
  averageprice?: number;
  buyprice?: number;
  quantity?: number;
  qty?: number;
  shares?: number;
  daychange?: number;
  change?: number;
  percentchange?: number;
  pnl?: number;
}
