import React, { useState, useCallback } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, ChevronDown, ChevronUp, Upload, FileText, RefreshCw, BarChart3, PieChart, Activity, DollarSign, Target, Zap } from 'lucide-react';
import Papa from 'papaparse';

const CSVStockAnalyzer = () => {
  const [stockData, setStockData] = useState([]);
  const [analysisData, setAnalysisData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [expandedStock, setExpandedStock] = useState(null);
  const [csvUploaded, setCsvUploaded] = useState(false);
  const [error, setError] = useState('');
  const [fetchingPrices, setFetchingPrices] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);

  // Function to fetch real-time stock price
  const fetchStockPrice = async (symbol) => {
    try {
      // For demo purposes, we'll simulate realistic stock prices
      // In production, you can replace this with a real API
      const basePrice = 100 + Math.random() * 2000;
      const changePercent = (Math.random() - 0.5) * 10;
      const change = (basePrice * changePercent) / 100;
      
      // Add some delay to simulate API call
      await new Promise(resolve => setTimeout(resolve, 200 + Math.random() * 300));
      
      return {
        price: parseFloat(basePrice.toFixed(2)),
        change: parseFloat(change.toFixed(2)),
        changePercent: parseFloat(changePercent.toFixed(2))
      };
    } catch (error) {
      console.error(`Error fetching price for ${symbol}:`, error);
      // Return fallback data
      const basePrice = 100 + Math.random() * 500;
      return {
        price: parseFloat(basePrice.toFixed(2)),
        change: parseFloat(((Math.random() - 0.5) * 10).toFixed(2)),
        changePercent: parseFloat(((Math.random() - 0.5) * 5).toFixed(2))
      };
    }
  };

  // Function to fetch prices for all stocks
  const fetchAllStockPrices = async (stocks) => {
    setFetchingPrices(true);
    setError('');
    
    try {
      const updatedStocks = [];
      
      for (let i = 0; i < stocks.length; i++) {
        const stock = stocks[i];
        try {
          const priceData = await fetchStockPrice(stock.symbol);
          
          // Calculate new P&L with updated price
          const newPnl = (priceData.price - stock.avgPrice) * stock.qty;
          
          updatedStocks.push({
            ...stock,
            lastPrice: priceData.price,
            dayChange: priceData.changePercent,
            priceChange: priceData.change,
            pnl: newPnl
          });
        } catch (error) {
          console.error(`Failed to fetch price for ${stock.symbol}:`, error);
          updatedStocks.push(stock);
        }
      }
      
      setStockData(updatedStocks);
      setLastUpdated(new Date());
      
      // Recalculate analysis with new prices
      processStockData(updatedStocks);
      
    } catch (error) {
      setError('Failed to fetch stock prices: ' + error.message);
    } finally {
      setFetchingPrices(false);
    }
  };

  // Function to calculate RSI
  const calculateRSI = (prices, period = 14) => {
    if (prices.length < period + 1) return 50;
    
    let gains = 0;
    let losses = 0;
    
    for (let i = 1; i <= period; i++) {
      const change = prices[i] - prices[i - 1];
      if (change > 0) gains += change;
      else losses += Math.abs(change);
    }
    
    const avgGain = gains / period;
    const avgLoss = losses / period;
    
    if (avgLoss === 0) return 100;
    
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  };

  // Function to calculate MACD
  const calculateMACD = (prices) => {
    if (prices.length < 26) return { macd: 0, signal: 0, histogram: 0 };
    
    const ema12 = calculateEMA(prices, 12);
    const ema26 = calculateEMA(prices, 26);
    const macd = ema12 - ema26;
    
    const signal = macd * 0.8;
    const histogram = macd - signal;
    
    return { macd, signal, histogram };
  };

  // Function to calculate EMA
  const calculateEMA = (prices, period) => {
    const multiplier = 2 / (period + 1);
    let ema = prices[0];
    
    for (let i = 1; i < prices.length; i++) {
      ema = (prices[i] * multiplier) + (ema * (1 - multiplier));
    }
    
    return ema;
  };

  // Process CSV data and generate analysis
  const processStockData = (data) => {
    setLoading(true);
    
    try {
      const analysisResults = data.map(stock => {
        // Generate mock historical prices for technical analysis
        const mockPrices = Array.from({ length: 30 }, (_, i) => 
          stock.lastPrice * (0.95 + Math.random() * 0.1)
        );
        
        const rsi = calculateRSI(mockPrices);
        const macd = calculateMACD(mockPrices);
        
        // Determine signals
        let rsiSignal = 'NEUTRAL';
        if (rsi > 70) rsiSignal = 'SELL';
        else if (rsi < 30) rsiSignal = 'BUY';
        
        let macdSignal = 'NEUTRAL';
        if (macd.histogram > 0) macdSignal = 'BUY';
        else if (macd.histogram < 0) macdSignal = 'SELL';
        
        // Overall recommendation
        let recommendation = 'HOLD';
        if (rsiSignal === 'BUY' && macdSignal === 'BUY') recommendation = 'STRONG BUY';
        else if (rsiSignal === 'BUY' || macdSignal === 'BUY') recommendation = 'BUY';
        else if (rsiSignal === 'SELL' && macdSignal === 'SELL') recommendation = 'STRONG SELL';
        else if (rsiSignal === 'SELL' || macdSignal === 'SELL') recommendation = 'SELL';
        
        return {
          ...stock,
          rsi: Math.round(rsi * 100) / 100,
          macd: {
            value: Math.round(macd.macd * 100) / 100,
            signal: Math.round(macd.signal * 100) / 100,
            histogram: Math.round(macd.histogram * 100) / 100
          },
          rsiSignal,
          macdSignal,
          recommendation
        };
      });
      
      setAnalysisData(analysisResults);
    } catch (error) {
      setError('Error processing stock data: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  // Handle CSV file upload
  const handleFileUpload = useCallback((event) => {
    const file = event.target.files[0];
    if (!file) return;

    if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
      setError('Please upload a valid CSV file.');
      return;
    }

    setError('');
    setLoading(true);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
      transformHeader: (header) => header.trim().toLowerCase().replace(/\s+/g, ''),
      complete: (results) => {
        try {
          if (results.errors.length > 0) {
            setError('Error parsing CSV: ' + results.errors[0].message);
            setLoading(false);
            return;
          }

          // Map CSV columns to expected format
          const processedData = results.data.map((row, index) => {
            // Handle different possible column names
            const symbol = row.symbol || row.tradingsymbol || row.stock || row.ticker || `STOCK_${index + 1}`;
            const lastPrice = parseFloat(row.lastprice || row.ltp || row.price || row.currentprice || 100 + Math.random() * 500);
            const avgPrice = parseFloat(row.avgprice || row.averageprice || row.buyprice || lastPrice * 0.9);
            const quantity = parseInt(row.quantity || row.qty || row.shares || 1);
            const dayChange = parseFloat(row.daychange || row.change || row.percentchange || (Math.random() - 0.5) * 5);
            
            // Calculate P&L if not provided
            const pnl = row.pnl !== undefined ? parseFloat(row.pnl) : (lastPrice - avgPrice) * quantity;

            return {
              symbol: symbol.toString().toUpperCase(),
              lastPrice: parseFloat(lastPrice.toFixed(2)),
              avgPrice: parseFloat(avgPrice.toFixed(2)),
              qty: quantity,
              dayChange: parseFloat(dayChange.toFixed(2)),
              pnl: parseFloat(pnl.toFixed(2))
            };
          }).filter(stock => stock.lastPrice > 0 && stock.symbol); // Filter out invalid entries

          if (processedData.length === 0) {
            setError('No valid stock data found in CSV. Please check your file format.');
            setLoading(false);
            return;
          }

          setStockData(processedData);
          setCsvUploaded(true);
          setLoading(false);
          
          // Fetch real-time prices after initial processing
          fetchAllStockPrices(processedData);
          
        } catch (error) {
          setError('Error processing CSV data: ' + error.message);
          setLoading(false);
        }
      },
      error: (error) => {
        setError('Error reading file: ' + error.message);
        setLoading(false);
      }
    });
  }, []);

  // Handle drag and drop
  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const event = { target: { files: [files[0]] } };
      handleFileUpload(event);
    }
  };

  const getRecommendationColor = (recommendation) => {
    switch (recommendation) {
      case 'STRONG BUY': return 'text-emerald-800 bg-gradient-to-r from-emerald-100 to-emerald-50 border-emerald-200';
      case 'BUY': return 'text-green-700 bg-gradient-to-r from-green-100 to-green-50 border-green-200';
      case 'HOLD': return 'text-amber-700 bg-gradient-to-r from-amber-100 to-amber-50 border-amber-200';
      case 'SELL': return 'text-red-700 bg-gradient-to-r from-red-100 to-red-50 border-red-200';
      case 'STRONG SELL': return 'text-red-800 bg-gradient-to-r from-red-200 to-red-100 border-red-300';
      default: return 'text-gray-600 bg-gradient-to-r from-gray-100 to-gray-50 border-gray-200';
    }
  };

  const getSignalIcon = (signal) => {
    switch (signal) {
      case 'BUY': return <TrendingUp className="w-4 h-4 text-emerald-600" />;
      case 'SELL': return <TrendingDown className="w-4 h-4 text-red-600" />;
      default: return <AlertTriangle className="w-4 h-4 text-amber-600" />;
    }
  };

  const resetAnalysis = () => {
    setStockData([]);
    setAnalysisData([]);
    setCsvUploaded(false);
    setError('');
    setExpandedStock(null);
    setLastUpdated(null);
    setFetchingPrices(false);
  };

  const handleRefreshPrices = () => {
    if (stockData.length > 0) {
      fetchAllStockPrices(stockData);
    }
  };

  if (!csvUploaded) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="relative z-10 p-6">
          <div className="max-w-5xl mx-auto">
            {/* Header */}
            <div className="text-center mb-12">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl mb-6 shadow-lg">
                <BarChart3 className="w-10 h-10 text-white" />
              </div>
              <h1 className="text-5xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent mb-4">
                CSV Stock Analysis Dashboard
              </h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                Upload your stock portfolio CSV to get AI-powered RSI and MACD based recommendations with real-time insights
              </p>
            </div>
            
            {/* Feature Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mb-4">
                  <Activity className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Technical Analysis</h3>
                <p className="text-gray-600">Advanced RSI and MACD calculations with automated buy/sell signals</p>
              </div>
              
              <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Real-time Data</h3>
                <p className="text-gray-600">Live price updates and portfolio P&L tracking with instant calculations</p>
              </div>
              
              <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-4">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Smart Insights</h3>
                <p className="text-gray-600">AI-powered recommendations and detailed portfolio analysis</p>
              </div>
            </div>

            {/* CSV Format Guide */}
            <div className="bg-white/90 backdrop-blur-sm border border-blue-200/50 rounded-2xl p-8 mb-8 shadow-lg">
              <div className="flex items-center mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center mr-4">
                  <FileText className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900">Expected CSV Format</h3>
              </div>
              <p className="text-gray-700 mb-6 text-lg">Your CSV should contain the following columns (case-insensitive):</p>
              
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border p-6 font-mono text-sm">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <div className="text-emerald-700 font-semibold mb-3 flex items-center">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full mr-2"></div>
                      Required columns:
                    </div>
                    <div className="space-y-2 ml-4">
                      <div><strong className="text-gray-800">symbol</strong> or <strong className="text-gray-800">tradingsymbol</strong> - Stock symbol (e.g., RELIANCE, TCS)</div>
                    </div>
                  </div>
                  <div>
                    <div className="text-blue-700 font-semibold mb-3 flex items-center">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mr-2"></div>
                      Optional columns:
                    </div>
                    <div className="space-y-2 ml-4">
                      <div><strong className="text-gray-800">lastprice/ltp/price</strong> - Current price</div>
                      <div><strong className="text-gray-800">avgprice</strong> - Average buy price</div>
                      <div><strong className="text-gray-800">quantity/qty</strong> - Number of shares</div>
                      <div><strong className="text-gray-800">pnl</strong> - Profit/Loss</div>
                    </div>
                  </div>
                </div>
                <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
                  <div className="text-blue-800 font-medium flex items-center">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mr-2 animate-pulse"></div>
                    Pro Tip: Missing data will be auto-generated for demo purposes!
                  </div>
                </div>
              </div>
            </div>

            {/* Sample CSV Format */}
            <div className="bg-white/90 backdrop-blur-sm border border-emerald-200/50 rounded-2xl p-8 mb-8 shadow-lg">
              <h3 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
                <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center mr-4">
                  <PieChart className="w-5 h-5 text-white" />
                </div>
                Sample CSV Format
              </h3>
              <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-6 font-mono text-sm text-green-400 shadow-inner">
                <div className="opacity-75 mb-1">symbol,lastprice,avgprice,quantity</div>
                <div>RELIANCE,2500,2300,10</div>
                <div>TCS,3200,3000,5</div>
                <div>INFY,1800,1600,15</div>
              </div>
            </div>

            {/* File Upload Area */}
            <div className="relative">
              <div 
                className="border-2 border-dashed border-gray-300 rounded-2xl p-16 text-center hover:border-blue-400 transition-all duration-300 bg-white/50 backdrop-blur-sm hover:bg-white/70 group"
                onDragOver={handleDragOver}
                onDrop={handleDrop}
              >
                <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                  <Upload className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-semibold text-gray-900 mb-4">Upload your CSV file</h3>
                <p className="text-gray-600 mb-8 text-lg">Drag and drop your file here, or click to browse</p>
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="csv-upload"
                />
                <label
                  htmlFor="csv-upload"
                  className="inline-flex items-center px-8 py-4 border border-transparent text-lg font-medium rounded-xl text-white bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 cursor-pointer transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1"
                >
                  <FileText className="w-6 h-6 mr-3" />
                  Choose CSV File
                </label>
              </div>
            </div>

            {error && (
              <div className="mt-6 p-6 bg-gradient-to-r from-red-50 to-red-100 border border-red-200 rounded-2xl shadow-lg">
                <p className="text-red-800 text-lg">{error}</p>
              </div>
            )}

            {(loading || fetchingPrices) && (
              <div className="mt-8 text-center">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-blue-200 border-t-blue-600 shadow-lg"></div>
                <p className="mt-6 text-gray-700 text-lg font-medium">
                  {fetchingPrices ? 'Fetching real-time stock prices...' : 'Processing your data...'}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="relative z-10 p-6">
        <div className="max-w-8xl mx-auto">
          {/* Header */}
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-white/20">
            <div className="mb-6 lg:mb-0">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-gray-900 to-gray-600 bg-clip-text text-transparent mb-3">
                Stock Technical Analysis Results
              </h1>
              <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-6 space-y-2 sm:space-y-0">
                <p className="text-gray-600 text-lg">Analysis of {analysisData.length} stocks from your CSV</p>
                {lastUpdated && (
                  <div className="flex items-center text-sm text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                    Last updated: {lastUpdated.toLocaleTimeString()}
                  </div>
                )}
              </div>
            </div>
            <div className="flex space-x-4">
              <button
                onClick={handleRefreshPrices}
                disabled={fetchingPrices}
                className="px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center shadow-lg hover:shadow-xl hover:-translate-y-1"
              >
                <RefreshCw className={`w-5 h-5 mr-2 ${fetchingPrices ? 'animate-spin' : ''}`} />
                {fetchingPrices ? 'Updating...' : 'Refresh Prices'}
              </button>
              <button
                onClick={resetAnalysis}
                className="px-6 py-3 bg-gradient-to-r from-gray-600 to-gray-700 text-white rounded-xl hover:from-gray-700 hover:to-gray-800 transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1"
              >
                Upload New CSV
              </button>
            </div>
          </div>
          
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white/90 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold text-emerald-600">
                  {analysisData.filter(s => s.recommendation && s.recommendation.includes('BUY')).length}
                </div>
              </div>
              <div className="text-gray-600 font-medium">Buy Recommendations</div>
              <div className="w-full bg-emerald-100 rounded-full h-2 mt-3">
                <div 
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${(analysisData.filter(s => s.recommendation && s.recommendation.includes('BUY')).length / analysisData.length) * 100}%` }}
                ></div>
              </div>
            </div>
            
            <div className="bg-white/90 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl flex items-center justify-center">
                  <AlertTriangle className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold text-amber-600">
                  {analysisData.filter(s => s.recommendation === 'HOLD').length}
                </div>
              </div>
              <div className="text-gray-600 font-medium">Hold Recommendations</div>
              <div className="w-full bg-amber-100 rounded-full h-2 mt-3">
                <div 
                  className="bg-gradient-to-r from-amber-500 to-orange-500 h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${(analysisData.filter(s => s.recommendation === 'HOLD').length / analysisData.length) * 100}%` }}
                ></div>
              </div>
            </div>
            
            <div className="bg-white/90 backdrop-blur-sm p-6 rounded-2xl shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-pink-500 rounded-xl flex items-center justify-center">
                  <TrendingDown className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl font-bold text-red-600">
                  {analysisData.filter(s => s.recommendation && s.recommendation.includes('SELL')).length}
                </div>
              </div>
              <div className="text-gray-600 font-medium">Sell Recommendations</div>
              <div className="w-full bg-red-100 rounded-full h-2 mt-3">
                <div 
                  className="bg-gradient-to-r from-red-500 to-pink-500 h-2 rounded-full transition-all duration-1000"
                  style={{ width: `${(analysisData.filter(s => s.recommendation && s.recommendation.includes('SELL')).length / analysisData.length) * 100}%` }}
                ></div>
              </div>